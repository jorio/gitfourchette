/*
 * This is a text file
 * Store it with LFS
 */

int foobar(void)
{
    return 0;
}
