/* This is another text file */
/* It starts out as non-LFS */
